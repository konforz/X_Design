//
//  ViewController.swift
//  X_Design
//
//  Created by MCS on 8/8/19.
//  Copyright © 2019 MCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func N(_ sender: UIButton) {
    }
    
    
    

    override func viewDidLoad() {
        
        // Do any additional setup after loading the view.
    }

}



